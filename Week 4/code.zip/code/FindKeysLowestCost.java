public class FindKeysLowestCost implements IFindKeys {
    @Override
    public int[] findKeys(int N, int k, ITreasureExtractor treasureExtractor) {
        // TODO: Problem 2 -- Implement strategy to find correct keys with minimum cost (least number of keys used in total across all attempts)
        return new int[N];
    }
}
